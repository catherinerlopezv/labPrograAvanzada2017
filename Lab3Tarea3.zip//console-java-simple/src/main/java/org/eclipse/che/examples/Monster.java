package org.eclipse.che.examples;

public interface Monster {
    
    
    public double getPower();
    public String ToAttack();


}
